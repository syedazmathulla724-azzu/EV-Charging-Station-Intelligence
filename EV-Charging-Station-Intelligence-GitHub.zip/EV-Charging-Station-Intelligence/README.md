# EV Charging Station Intelligence Dashboard

## Project Overview
An end-to-end Power BI analytics project for understanding EV charging demand, station performance, revenue, utilization and operational risk across an Irish charging network.

## Business Problem
Charging-network operators need to know:
- Which stations generate the most revenue?
- When is charging demand highest?
- Which stations are under-utilized or overloaded?
- What proportion of sessions fail?
- Which charger types drive energy and revenue?
- How does performance change over time?

## Objectives
1. Monitor network-level KPIs.
2. Compare station and city performance.
3. Identify peak demand periods.
4. Analyze charger-type economics.
5. Flag operational issues using DAX-driven measures.

## Dataset
Synthetic but realistic 2025 Irish EV charging data:
- 15,000 charging sessions
- 30 charging stations
- 500 vehicles
- 365 calendar dates

## Tables
- Fact_Charging_Sessions
- Dim_Station
- Dim_Vehicle
- Dim_Date
- Fact_Station_Daily (supporting operational analysis)

## Power BI Skills
Power Query, star-schema modelling, relationships, calculated measures, time intelligence, KPI cards, slicers, matrix heatmaps, drill-through, tooltips and DAX.

## DAX Functions Demonstrated
SUM, COUNTROWS, DISTINCTCOUNT, AVERAGE, DIVIDE, CALCULATE, FILTER, ALL, SUMX, AVERAGEX, RANKX, TOPN, SWITCH, IF, DATEADD, DATESYTD, DIVIDE.

## Dashboard Pages
1. Executive Overview
2. Station Intelligence
3. Demand & Peak Analysis
4. Operational Actions

## Key Business Questions
- What is total revenue and energy delivered?
- Which stations are top performers?
- What are the peak charging hours?
- Which stations have high failure rates?
- Which stations are under-utilized?
- What is the month-over-month revenue growth?

## Important Note
The data is synthetic and created for portfolio/learning purposes. It does not represent real customer or company data.
