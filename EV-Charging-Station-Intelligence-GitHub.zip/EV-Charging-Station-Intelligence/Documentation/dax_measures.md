# DAX Measures

```DAX
Total Revenue = SUM(Fact_Charging_Sessions[Revenue])

Charging Sessions = DISTINCTCOUNT(Fact_Charging_Sessions[Session_ID])

Completed Sessions =
CALCULATE([Charging Sessions], Fact_Charging_Sessions[Status] = "Completed")

Failed Sessions =
CALCULATE([Charging Sessions], Fact_Charging_Sessions[Status] = "Failed")

Failure Rate = DIVIDE([Failed Sessions], [Charging Sessions])

Total Energy = SUM(Fact_Charging_Sessions[Energy_kWh])

Average Session Duration =
AVERAGE(Fact_Charging_Sessions[Duration_Minutes])

Revenue Per Session =
DIVIDE([Total Revenue], [Completed Sessions])

Energy Per Session =
DIVIDE([Total Energy], [Completed Sessions])

Peak Sessions =
CALCULATE([Charging Sessions], Fact_Charging_Sessions[Peak_Period] = "Peak")

Peak Session % =
DIVIDE([Peak Sessions], [Charging Sessions])

Weekend Revenue =
CALCULATE([Total Revenue], Fact_Charging_Sessions[Day_Type] = "Weekend")

Revenue YTD =
TOTALYTD([Total Revenue], Dim_Date[Date])

Previous Month Revenue =
CALCULATE([Total Revenue], DATEADD(Dim_Date[Date], -1, MONTH))

Revenue Growth % =
DIVIDE([Total Revenue] - [Previous Month Revenue], [Previous Month Revenue])

Station Rank =
RANKX(ALL(Dim_Station[Station_Name]), [Total Revenue], , DESC)

Top 5 Station Revenue =
CALCULATE(
    [Total Revenue],
    TOPN(5, ALL(Dim_Station[Station_Name]), [Total Revenue], DESC)
)

Revenue Contribution % =
DIVIDE(
    [Total Revenue],
    CALCULATE([Total Revenue], ALL(Dim_Station))
)

Average Revenue per kWh =
DIVIDE([Total Revenue], [Total Energy])

Station Utilization % =
DIVIDE(
    SUM(Fact_Station_Daily[Occupied_Hours]),
    SUM(Fact_Station_Daily[Estimated_Available_Hours])
)

Station Risk =
SWITCH(
    TRUE(),
    [Failure Rate] >= 0.08, "High Failure Risk",
    [Station Utilization %] >= 0.75, "High Demand",
    [Station Utilization %] <= 0.20, "Underutilized",
    "Healthy"
)

High Demand Stations =
COUNTROWS(
    FILTER(
        VALUES(Dim_Station[Station_ID]),
        [Station Utilization %] >= 0.75
    )
)
```
