# Power BI Build Guide

## Relationships
- Dim_Date[Date] 1 -> * Fact_Charging_Sessions[Date]
- Dim_Station[Station_ID] 1 -> * Fact_Charging_Sessions[Station_ID]
- Dim_Vehicle[Vehicle_ID] 1 -> * Fact_Charging_Sessions[Vehicle_ID]
- Dim_Date[Date] 1 -> * Fact_Station_Daily[Date]
- Dim_Station[Station_ID] 1 -> * Fact_Station_Daily[Station_ID]

Use single-direction filtering from dimensions to facts.

## Page 1 — Executive Overview
Cards: Total Revenue, Charging Sessions, Total Energy, Failure Rate, Revenue per Session.
Charts: monthly revenue line chart, revenue by city bar chart, energy by charger type donut/bar, sessions by day type.
Slicers: Date, City, Charger Type.

## Page 2 — Station Intelligence
Matrix: Station, City, Revenue, Sessions, Utilization %, Failure Rate, Station Rank.
Bar chart: Top 10 stations by revenue.
Scatter: Utilization % vs Revenue, bubble size = sessions.
Conditional formatting: Station Risk.

## Page 3 — Demand & Peak Analysis
Heatmap/matrix: Day Name × Hour with session count.
Line chart: monthly sessions.
Column chart: sessions by charger type.
Cards: Peak Sessions, Peak Session %.
Slicers: City, Charger Type, Day Type.

## Page 4 — Operational Actions
Table of stations with Risk, Utilization, Failure Rate and Revenue.
Use a KPI/table to highlight:
- High Failure Risk
- High Demand
- Underutilized
- Healthy

## Design
Keep a clean white/very-light background, 2–3 accent colours, consistent typography, aligned visuals, and minimal decoration.
