# Data Dictionary

## Fact_Charging_Sessions
| Column | Description |
|---|---|
| Session_ID | Unique charging session |
| Date | Session date |
| Station_ID | Station key |
| Vehicle_ID | Vehicle key |
| Charger_Type | AC, DC Fast or Ultra-Fast |
| Start_Time | Session start timestamp |
| End_Time | Session end timestamp |
| Duration_Minutes | Charging duration |
| Energy_kWh | Energy delivered |
| Price_Per_kWh | Price charged per kWh |
| Status | Completed or Failed |
| Revenue | Session revenue |
| Peak_Period | Peak or Off-Peak |
| Day_Type | Weekday or Weekend |
| Hour | Start hour |

## Dim_Station
Station master data including city, province, location type, charger type and connector count.

## Dim_Vehicle
Vehicle model, customer type and vehicle segment.

## Dim_Date
Calendar attributes for time intelligence.

## Fact_Station_Daily
Daily station-level operational summary used for utilization and station performance analysis.
